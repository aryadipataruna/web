<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ReUse Mart - Riwayat Pembelian</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-dark: #0a0a0a;
            --secondary-dark: #1a1a1a;
            --card-dark: #2a2a2a;
            --accent-green: #00ff88;
            --accent-blue: #00aaff;
            --text-light: #f8f9fa;
            --text-muted: #adb5bd;
            --star-gold: #FFD700; /* Gold color for stars */
        }

        * {
            scroll-behavior: smooth;
        }

        body {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--secondary-dark) 100%);
            color: var(--text-light);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            padding-top: 80px; /* To prevent content from being hidden by fixed navbar */
        }

        /* Navbar Styles */
        .navbar {
            background: rgba(26, 26, 26, 0.95);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 2px 20px rgba(0, 0, 0, 0.3);
        }

        .navbar-brand {
            font-size: 1.5rem;
            font-weight: bold;
            background: linear-gradient(45deg, var(--accent-green), var(--accent-blue));
            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            transition: all 0.3s ease;
        }

        .navbar-brand:hover {
            transform: scale(1.05);
        }

        .search-container {
            position: relative;
            max-width: 600px;
            margin: 0 auto;
        }

        .search-input {
            background: rgba(255, 255, 255, 0.1);
            border: 2px solid rgba(255, 255, 255, 0.2);
            border-radius: 50px;
            color: white;
            padding: 12px 50px 12px 20px;
            transition: all 0.3s ease;
        }

        .search-input:focus {
            background: rgba(255, 255, 255, 0.15);
            border-color: var(--accent-green);
            box-shadow: 0 0 20px rgba(0, 255, 136, 0.3);
            color: white;
        }

        .search-btn {
            position: absolute;
            right: 5px;
            top: 50%;
            transform: translateY(-50%);
            background: linear-gradient(45deg, var(--accent-green), var(--accent-blue));
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            color: white;
            transition: all 0.3s ease;
        }

        .search-btn:hover {
            transform: translateY(-50%) scale(1.1);
            box-shadow: 0 5px 15px rgba(0, 255, 136, 0.4);
        }

        /* Section Title */
        .section-title {
            font-size: 2.5rem;
            font-weight: bold;
            text-align: center;
            margin-bottom: 3rem;
            background: linear-gradient(45deg, var(--accent-green), var(--accent-blue));
            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        /* History Card */
        .history-card {
            background: var(--card-dark);
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            transition: all 0.3s ease;
            position: relative;
        }

        .history-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
            border-color: var(--accent-green);
        }

        .history-image {
            width: 100%;
            height: 200px; /* Slightly smaller for history view */
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .history-card:hover .history-image {
            transform: scale(1.05);
        }

        .history-info {
            padding: 1.5rem;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            position: relative;
            z-index: 2;
        }

        .history-title {
            font-size: 1.2rem;
            font-weight: bold;
            margin-bottom: 0.5rem;
            color: var(--text-light);
        }

        .history-description {
            color: var(--text-muted);
            font-size: 0.9rem;
            margin-bottom: 1rem;
            flex-grow: 1;
        }

        .history-price {
            font-size: 1.1rem;
            font-weight: bold;
            color: var(--accent-green); /* Price can be green */
            margin-bottom: 0.5rem;
        }

        .history-date {
            font-size: 0.85rem;
            color: var(--text-muted);
            margin-bottom: 1rem;
        }

        /* Rating Stars */
        .rating-stars {
            font-size: 1.5rem; /* Ukuran bintang */
            color: var(--text-muted); /* Warna default bintang kosong */
            cursor: pointer;
            text-align: center;
            margin-top: 1rem;
            display: flex; /* Menggunakan flexbox untuk penataan */
            justify-content: center; /* Pusatkan bintang */
            gap: 2px; /* Jarak antar bintang */
        }

        .rating-stars .fa-star,
        .rating-stars .fa-star-o {
            transition: all 0.2s ease;
            color: inherit; /* Warna default dari parent */
        }

        .rating-stars .fa-star.filled {
            color: var(--star-gold); /* Warna emas untuk bintang terisi */
        }

        .rating-stars .fa-star-o {
             color: var(--text-muted); /* Pastikan bintang kosong terlihat */
        }

        .rating-stars .fa-star:hover,
        .rating-stars .fa-star-o:hover {
            transform: scale(1.1); /* Efek zoom saat hover */
            color: var(--star-gold); /* Bintang yang di-hover berubah jadi emas */
        }

        .rating-text {
            font-size: 0.9rem;
            color: var(--text-muted);
            text-align: center;
            margin-top: 0.5rem;
        }

        /* Add this for the gold color for stars (if not already present) */
        :root {
            --primary-dark: #0a0a0a;
            --secondary-dark: #1a1a1a;
            --card-dark: #2a2a2a;
            --accent-green: #00ff88;
            --accent-blue: #00aaff;
            --text-light: #f8f9fa;
            --text-muted: #adb5bd;
            --star-gold: #FFD700; /* Gold color for stars */
        }

        /* Nav Links */
        .nav-link {
            transition: all 0.3s ease;
            border-radius: 10px;
            padding: 8px 16px !important;
        }

        .nav-link:hover {
            background: rgba(0, 255, 136, 0.1);
            color: var(--accent-green) !important;
            transform: translateY(-2px);
        }

        /* Footer */
        footer {
            background: var(--secondary-dark);
            border-top: 1px solid rgba(255,255,255,0.1);
        }

        footer h5 {
            background: linear-gradient(45deg, var(--accent-green), var(--accent-blue));
            background-clip: text;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: bold;
        }

        footer .list-unstyled a {
            transition: color 0.3s ease;
        }

        footer .list-unstyled a:hover {
            color: var(--accent-green) !important;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark fixed-top px-4">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.html">
            <i class="fa fa-recycle me-2"></i>ReUse <strong>Mart</strong>
        </a>
        
        <div class="search-container flex-grow-1 mx-4">
            <input class="form-control search-input" type="search" placeholder="Cari barang bekas berkualitas..." id="searchInput">
            <button class="btn search-btn" type="button">
                <i class="fa fa-search"></i>
            </button>
        </div>
        
        <div class="d-flex align-items-center">
            <a href="index.html#categories" class="nav-link text-light me-2">
                <i class="fa fa-th-large me-1"></i>Kategori
            </a>
            <a href="index.html#products" class="nav-link text-light me-2">
                <i class="fa fa-shopping-bag me-1"></i>Produk
            </a>
            <a href="#" class="nav-link text-light me-2">
                <i class="fa fa-shopping-cart me-1"></i>Keranjang
            </a>
            <a href="#" class="nav-link text-light me-2 active">
                <i class="fa fa-history me-1"></i>Riwayat
            </a>
            <a href="#" class="nav-link text-light">
                <i class="fa fa-user me-1"></i>Masuk
            </a>
        </div>
    </div>
</nav>

<section class="py-5" id="history">
    <div class="container">
        <h2 class="section-title">Riwayat Pembelian Anda</h2>
        <div class="row g-4" id="historyItemsRow">
            <div class="col-lg-3 col-md-6">
                <div class="history-card">
                    <img src="https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=400&h=250&fit=crop" alt="TV Samsung" class="history-image">
                    <div class="history-info">
                        <h5 class="history-title">TV Samsung 50 inch</h5>
                        <p class="history-description">Smart TV LED 4K, kondisi sangat baik, lengkap dengan remote dan dus.</p>
                        <div class="history-price">Rp 3.500.000</div>
                        <div class="history-date">Dibeli pada: 20 Mei 2024</div>
                        <div class="rating-stars" data-rating="4"> <i class="fa fa-star-o" data-value="1"></i>
                            <i class="fa fa-star-o" data-value="2"></i>
                            <i class="fa fa-star-o" data-value="3"></i>
                            <i class="fa fa-star-o" data-value="4"></i>
                            <i class="fa fa-star-o" data-value="5"></i>
                        </div>
                        <p class="rating-text">Nilai produk ini!</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="history-card">
                    <img src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400&h=250&fit=crop" alt="Sepeda Statis" class="history-image">
                    <div class="history-info">
                        <h5 class="history-title">Sepeda Statis</h5>
                        <p class="history-description">Alat fitness berkualitas, jarang dipakai, cocok untuk home gym.</p>
                        <div class="history-price">Rp 1.200.000</div>
                        <div class="history-date">Dibeli pada: 15 April 2024</div>
                        <div class="rating-stars" data-rating="5">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                        </div>
                        <p class="rating-text">Nilai produk ini!</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="history-card">
                    <img src="https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400&h=250&fit=crop" alt="Laptop Gaming" class="history-image">
                    <div class="history-info">
                        <h5 class="history-title">Laptop Gaming ASUS</h5>
                        <p class="history-description">ROG series, spek tinggi, cocok untuk gaming dan design.</p>
                        <div class="history-price">Rp 8.500.000</div>
                        <div class="history-date">Dibeli pada: 1 Maret 2024</div>
                        <div class="rating-stars" data-rating="0">
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                        </div>
                        <p class="rating-text">Nilai produk ini!</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="history-card">
                    <img src="https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=250&fit=crop" alt="Kursi Antik" class="history-image">
                    <div class="history-info">
                        <h5 class="history-title">Kursi Kayu Antik</h5>
                        <p class="history-description">Furniture vintage berkualitas tinggi, cocok untuk dekorasi rumah.</p>
                        <div class="history-price">Rp 750.000</div>
                        <div class="history-date">Dibeli pada: 10 Februari 2024</div>
                        <div class="rating-stars" data-rating="3">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star-o"></i>
                            <i class="fa fa-star-o"></i>
                        </div>
                        <p class="rating-text">Nilai produk ini!</p>
                    </div>
                </div>
            </div>
            </div>
    </div>
</section>

<footer class="py-5 mt-5" style="background: var(--secondary-dark); border-top: 1px solid rgba(255,255,255,0.1);">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h5 class="mb-3">
                    <i class="fa fa-recycle me-2"></i>ReUse Mart
                </h5>
                <p class="text-muted">Marketplace terpercaya untuk barang bekas berkualitas. Bersama kita ciptakan masa depan yang lebih berkelanjutan.</p>
                <div class="d-flex gap-3 mt-3">
                    <a href="#" class="text-light"><i class="fab fa-facebook fa-lg"></i></a>
                    <a href="#" class="text-light"><i class="fab fa-instagram fa-lg"></i></a>
                    <a href="#" class="text-light"><i class="fab fa-twitter fa-lg"></i></a>
                    <a href="#" class="text-light"><i class="fab fa-whatsapp fa-lg"></i></a>
                </div>
            </div>
            <div class="col-md-2">
                <h6>Kategori</h6>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-muted text-decoration-none">Elektronik</a></li>
                    <li><a href="#" class="text-muted text-decoration-none">Furniture</a></li>
                    <li><a href="#" class="text-muted text-decoration-none">Otomotif</a></li>
                    <li><a href="#" class="text-muted text-decoration-none">Fashion</a></li>
                </ul>
            </div>
            <div class="col-md-2">
                <h6>Bantuan</h6>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-muted text-decoration-none">FAQ</a></li>
                    <li><a href="#" class="text-muted text-decoration-none">Cara Beli</a></li>
                    <li><a href="#" class="text-muted text-decoration-none">Cara Jual</a></li>
                    <li><a href="#" class="text-muted text-decoration-none">Kontak</a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const ratingContainers = document.querySelectorAll('.rating-stars');

        ratingContainers.forEach(container => {
            const stars = Array.from(container.children); // Get all <i> elements
            const ratingText = container.nextElementSibling; // Assuming rating-text is the next sibling

            // Function to render stars based on a given integer rating value (1-5)
            function renderStars(ratingValue) {
                stars.forEach((star, index) => {
                    if (index < ratingValue) {
                        star.classList.remove('fa-star-o');
                        star.classList.add('fa-star', 'filled');
                    } else {
                        star.classList.remove('fa-star', 'filled');
                        star.classList.add('fa-star-o');
                    }
                });

                if (ratingValue === 0) {
                    ratingText.textContent = 'Nilai produk ini!';
                } else {
                    ratingText.textContent = `Anda memberi ${ratingValue} bintang`;
                }
            }

            // Set initial stars based on data-rating attribute
            const initialRating = parseInt(container.dataset.rating || 0);
            renderStars(initialRating);

            stars.forEach((star, index) => {
                star.addEventListener('click', () => {
                    const newRating = index + 1; // Rating is 1-indexed
                    container.dataset.rating = newRating; // Update the data-rating attribute
                    renderStars(newRating);
                    console.log(`Product rated ${newRating} stars.`);
                    // You would typically send this rating to your backend here
                });

                star.addEventListener('mouseover', () => {
                    // Fill stars up to the hovered star
                    stars.forEach((s, i) => {
                        if (i <= index) {
                            s.classList.remove('fa-star-o');
                            s.classList.add('fa-star', 'filled');
                        } else {
                            s.classList.remove('fa-star', 'filled');
                            s.classList.add('fa-star-o');
                        }
                    });
                });

                star.addEventListener('mouseout', () => {
                    // Revert to the actual rating when mouse leaves the star area
                    renderStars(parseInt(container.dataset.rating));
                });
            });
        });
    });
</script>
</body>
</html><?php /**PATH D:\kuliah\P3L\project\web\p3l\resources\views/historyPage.blade.php ENDPATH**/ ?>